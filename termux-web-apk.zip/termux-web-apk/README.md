# Termux Web (APK)

A WebView app that wraps termux-web.html and drives the REAL Termux.

## Build
- Phone/cloud: push this folder to a GitHub repo; the "Build APK" action produces app-debug.apk (Actions > run > Artifacts).
- PC / AndroidIDE: ./gradlew assembleDebug  ->  app/build/outputs/apk/debug/app-debug.apk

## One-time setup on the phone
1. Install Termux from F-Droid or GitHub (not the Play Store build).
2. In Termux run:
   mkdir -p ~/.termux && echo "allow-external-apps=true" >> ~/.termux/termux.properties
   then close and reopen Termux.
3. Open Termux Web and allow the "Run commands in Termux" permission.
   The app installs python in Termux if needed, starts the bridge, and connects. First start can take a minute.
4. If it did not connect, run:  bridge start  in the app.

Without Termux the app still works as the simulated shell.
