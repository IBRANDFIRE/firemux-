package com.ibrandfire.termuxweb;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.SecureRandom;
import java.util.ArrayList;

public class MainActivity extends Activity {
    static final String TERMUX = "com.termux";
    static final String RUN_PERM = "com.termux.permission.RUN_COMMAND";
    static final int PORT = 8022;
    static final int REQ_PERMS = 7, REQ_FILE = 8, REQ_GEO = 9;

    // Runs inside Termux: installs python if missing, then starts bridge.py ($1) with token ($2) and port ($3).
    static final String SCRIPT =
            "command -v python >/dev/null 2>&1 || pkg install -y python; "
            + "TW_TOKEN=\"$2\" PORT=\"$3\" exec python -c \"$1\"";

    // Terminal libraries served from the app so they work offline.
    static final String[][] OFFLINE = {
            {"https://cdnjs.cloudflare.com/ajax/libs/xterm/5.3.0/xterm.min.js", "offline/xterm.js", "application/javascript"},
            {"https://cdnjs.cloudflare.com/ajax/libs/xterm/5.3.0/xterm.min.css", "offline/xterm.css", "text/css"},
            {"https://cdnjs.cloudflare.com/ajax/libs/xterm-addon-fit/0.8.0/xterm-addon-fit.min.js", "offline/xterm-addon-fit.js", "application/javascript"}
    };

    WebView web;
    ValueCallback<Uri[]> chooser;
    String token;
    GeolocationPermissions.Callback geoCb;
    String geoOrigin;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences("tw", MODE_PRIVATE);
        token = sp.getString("token", null);
        if (token == null) {
            byte[] r = new byte[18];
            new SecureRandom().nextBytes(r);
            token = Base64.encodeToString(r, Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
            sp.edit().putString("token", token).apply();
        }
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setSupportMultipleWindows(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Api(), "TermuxApp");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.loadUrl("file:///android_asset/termux-web.html#bridge=" + PORT + ":" + token);
        askPermissions();
    }

    boolean termuxInstalled() {
        try {
            getPackageManager().getPackageInfo(TERMUX, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    void askPermissions() {
        ArrayList<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 23) {
            if (Build.VERSION.SDK_INT < 29
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            if (termuxInstalled() && checkSelfPermission(RUN_PERM) != PackageManager.PERMISSION_GRANTED)
                need.add(RUN_PERM);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERMS);
        else web.postDelayed(this::startBridge, 1500);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        if (code == REQ_PERMS) web.postDelayed(this::startBridge, 500);
        else if (code == REQ_GEO && geoCb != null) {
            geoCb.invoke(geoOrigin, res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED, false);
            geoCb = null;
        }
    }

    void startBridge() {
        if (!termuxInstalled()) {
            notice("Termux is not installed. Install the F-Droid or GitHub build of Termux, then run: bridge start");
            return;
        }
        String code;
        try {
            code = readAsset("bridge.py");
        } catch (IOException e) {
            notice("bridge.py is missing from the app.");
            return;
        }
        Intent i = new Intent();
        i.setClassName(TERMUX, "com.termux.app.RunCommandService");
        i.setAction("com.termux.RUN_COMMAND");
        i.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
        i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS",
                new String[]{"-c", SCRIPT, "bridge", code, token, String.valueOf(PORT)});
        i.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
        i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (SecurityException e) {
            notice("Termux refused the request. In Termux run: mkdir -p ~/.termux && echo allow-external-apps=true >> ~/.termux/termux.properties  then restart Termux and run: bridge start");
        } catch (Exception e) {
            notice("Could not start Termux: " + e.getMessage());
        }
    }

    void notice(String msg) {
        runOnUiThread(() -> web.evaluateJavascript(
                "window.twNotice&&twNotice(" + JSONObject.quote(msg) + ")", null));
    }

    void toast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
    }

    String readAsset(String name) throws IOException {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
            return o.toString("UTF-8");
        }
    }

    boolean route(Uri u) {
        if (u.toString().startsWith("file:///android_asset/")) return false;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception e) {
            toast("Cannot open " + u);
        }
        return true;
    }

    class Api {
        @JavascriptInterface
        public void startBridge() {
            runOnUiThread(MainActivity.this::startBridge);
        }

        @JavascriptInterface
        public boolean saveFile(String name, String b64) {
            try {
                byte[] data = Base64.decode(b64, Base64.DEFAULT);
                String fn = new File(name).getName();
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, fn);
                    Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    try (OutputStream os = getContentResolver().openOutputStream(u)) {
                        os.write(data);
                    }
                } else {
                    File d = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    d.mkdirs();
                    try (FileOutputStream os = new FileOutputStream(new File(d, fn))) {
                        os.write(data);
                    }
                }
                toast("Saved to Downloads: " + fn);
                return true;
            } catch (Exception e) {
                toast("Save failed: " + e.getMessage());
                return false;
            }
        }
    }

    class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            String u = r.getUrl().toString();
            for (String[] o : OFFLINE) {
                if (o[0].equals(u)) {
                    try {
                        return new WebResourceResponse(o[2], "UTF-8", getAssets().open(o[1]));
                    } catch (IOException e) {
                        return null;
                    }
                }
            }
            return null;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return route(r.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, String u) {
            return route(Uri.parse(u));
        }
    }

    class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (chooser != null) chooser.onReceiveValue(null);
            chooser = cb;
            try {
                startActivityForResult(p.createIntent(), REQ_FILE);
            } catch (Exception e) {
                chooser = null;
                return false;
            }
            return true;
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            if (Build.VERSION.SDK_INT >= 23
                    && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                geoCb = cb;
                geoOrigin = origin;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_GEO);
            } else {
                cb.invoke(origin, true, false);
            }
        }

        @Override
        public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message m) {
            WebView t = new WebView(MainActivity.this);
            t.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest r) {
                    return route(r.getUrl());
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView w, String u) {
                    return route(Uri.parse(u));
                }
            });
            ((WebView.WebViewTransport) m.obj).setWebView(t);
            m.sendToTarget();
            return true;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && chooser != null) {
            chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooser = null;
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }
}
