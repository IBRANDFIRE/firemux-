#!/usr/bin/env python3
# Termux Web bridge: gives termux-web.html a real shell. Run it inside Termux.
# Usage: python bridge.py [path/to/termux-web.html]
import os, sys, pty, fcntl, termios, struct, select, socket, threading
import hashlib, base64, secrets, hmac, json, signal, urllib.parse

PORT = int(os.environ.get("PORT", "8022"))
TOKEN = os.environ.get("TW_TOKEN") or secrets.token_urlsafe(16)
HERE = os.path.dirname(os.path.abspath(__file__))
HTML = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "termux-web.html")
GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
OK_ORIGINS = (None, "null", "file://", "http://127.0.0.1:%d" % PORT, "http://localhost:%d" % PORT)


def read_headers(c):
    buf = b""
    while b"\r\n\r\n" not in buf:
        d = c.recv(4096)
        if not d or len(buf) > 65536:
            return None
        buf += d
    lines = buf.split(b"\r\n\r\n", 1)[0].decode("latin1").split("\r\n")
    method, path, _ = lines[0].split(" ", 2)
    h = {}
    for l in lines[1:]:
        if ":" in l:
            k, v = l.split(":", 1)
            h[k.strip().lower()] = v.strip()
    return method, path, h


def send(c, data, op=2):
    n = len(data)
    head = bytes([0x80 | op])
    if n < 126:
        head += bytes([n])
    elif n < 65536:
        head += bytes([126]) + struct.pack(">H", n)
    else:
        head += bytes([127]) + struct.pack(">Q", n)
    c.sendall(head + data)


def recv_exact(c, n):
    b = b""
    while len(b) < n:
        d = c.recv(n - len(b))
        if not d:
            raise EOFError
        b += d
    return b


def read_frame(c):
    b1, b2 = recv_exact(c, 2)
    op, n = b1 & 15, b2 & 127
    if n == 126:
        n = struct.unpack(">H", recv_exact(c, 2))[0]
    elif n == 127:
        n = struct.unpack(">Q", recv_exact(c, 8))[0]
    mask = recv_exact(c, 4) if b2 & 128 else None
    data = recv_exact(c, n)
    if mask:
        data = bytes(x ^ mask[i % 4] for i, x in enumerate(data))
    return op, data


def session(c):
    pid, fd = pty.fork()
    if pid == 0:
        try:
            os.chdir(os.path.expanduser("~"))
            os.environ["TERM"] = "xterm-256color"
            cands = [os.environ.get("SHELL"), os.environ.get("PREFIX", "") + "/bin/bash", "/bin/sh", "/system/bin/sh"]
            shell = next(p for p in cands if p and os.path.exists(p))
            os.execvp(shell, [shell])
        finally:
            os._exit(1)
    lock, stop = threading.Lock(), threading.Event()

    def pump():
        try:
            while not stop.is_set():
                r, _, _ = select.select([fd], [], [], 0.5)
                if r:
                    d = os.read(fd, 4096)
                    if not d:
                        break
                    with lock:
                        send(c, d)
        except OSError:
            pass
        finally:
            stop.set()
            try:
                with lock:
                    send(c, b"", 8)
            except Exception:
                pass

    threading.Thread(target=pump, daemon=True).start()
    try:
        while not stop.is_set():
            op, data = read_frame(c)
            if op == 8:
                break
            if op == 9:
                with lock:
                    send(c, data, 10)
            elif op in (1, 2):
                if data[:1] == b"\x00":
                    m = json.loads(data[1:])
                    size = struct.pack("HHHH", int(m["rows"]), int(m["cols"]), 0, 0)
                    fcntl.ioctl(fd, termios.TIOCSWINSZ, size)
                else:
                    os.write(fd, data)
    except Exception:
        pass
    finally:
        stop.set()
        for s in (signal.SIGHUP, signal.SIGKILL):
            try:
                os.kill(pid, s)
            except OSError:
                pass
        try:
            os.waitpid(pid, 0)
            os.close(fd)
        except OSError:
            pass


def handle(c):
    try:
        r = read_headers(c)
        if not r:
            return
        method, path, h = r
        u = urllib.parse.urlparse(path)
        if h.get("upgrade", "").lower() == "websocket":
            tok = (urllib.parse.parse_qs(u.query).get("token") or [""])[0]
            if not (hmac.compare_digest(tok.encode(), TOKEN.encode()) and h.get("origin") in OK_ORIGINS):
                c.sendall(b"HTTP/1.1 403 Forbidden\r\nContent-Length: 0\r\n\r\n")
                return
            acc = base64.b64encode(hashlib.sha1(h["sec-websocket-key"].encode() + GUID).digest())
            c.sendall(b"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + acc + b"\r\n\r\n")
            session(c)
        elif u.path == "/" and os.path.exists(HTML):
            body = open(HTML, "rb").read()
            c.sendall(b"HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nCache-Control: no-store\r\nContent-Length: " + str(len(body)).encode() + b"\r\n\r\n" + body)
        else:
            c.sendall(b"HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n")
    except Exception:
        pass
    finally:
        c.close()


def main():
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("127.0.0.1", PORT))
    s.listen(5)
    print("Termux Web bridge is running (only this phone can reach it).")
    print("Open this address in your browser:")
    print("  http://127.0.0.1:%d/#%s" % (PORT, TOKEN))
    print("Or, in the app opened from a file, run:")
    print("  bridge connect %d %s" % (PORT, TOKEN))
    print("Press CTRL+C to stop.")
    try:
        while True:
            c, _ = s.accept()
            threading.Thread(target=handle, args=(c,), daemon=True).start()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
